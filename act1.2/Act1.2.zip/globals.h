#ifndef GLOBALS_H
#define GLOBALS_H

extern int comparacionesGlobales;

#endif // GLOBALS_H
